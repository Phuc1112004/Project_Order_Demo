import axios from "axios";


const API_URL = 'http://localhost:8080/api/v1';

// export const fetchCustomers = async () =>{
//     const response = await axios.get(`${API_URL}/customers`);
//     return response.data.content;
// }

// export const fetchProducts = async () =>{
//     const response = await axios.get(`${API_URL}/products`);
//     return response.data.content;
// }

export const fetchOrders = async () =>{
    const response = await axios.get(`${API_URL}/orders`);
    return response.data;
}

export const addOrder = async (order) => {
   const response = await axios.post(`${API_URL}/orders`,order);
   return response.data;
}

export const updateOrder = async (id,order) => {
    const response = await axios.put(`${API_URL}/orders/${id}`,order);
    return response.data;
}

export const deleteOrder = async (id) => {
    await axios.delete(`${API_URL}/orders/${id}`);
}

